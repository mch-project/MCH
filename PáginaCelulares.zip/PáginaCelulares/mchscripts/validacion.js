	// JavaScript Document
function valida(nombre,a,b,c,d){
	//declaramos variables
	var valor;
	var msg_error='';
	//	getElementById("nav")
	var elemento = document.getElementById(nombre);
	valor = document.getElementById(nombre).value;
	//validamos sea n�mero
	if (!isNaN(valor)){
		//validaciones de rangos
		//alert("valor=" +valor);
		if (valor== "" ){
			//firefox
			elemento.setAttribute('class','normal');
			//IE
			elemento.setAttribute('className','normal');
		} else if (valor <= a){
			//firefox
			elemento.setAttribute('class','rojo');
			//IE
			elemento.setAttribute('className','rojo');
		} else if( valor > a && valor < b){
			//firefox
			elemento.setAttribute('class','naranja');
			//IE
			elemento.setAttribute('className','naranja');
		} else if (valor >=b && valor <=c){
			//firefox
			elemento.setAttribute('class','normal');
			//IE
			elemento.setAttribute('className','normal');
		} else if (valor > c && valor < d) {
			//firefox
			elemento.setAttribute('class','morado');
			//IE
			elemento.setAttribute('className','morado');
		} else if (valor >= d){
			//firefox
			elemento.setAttribute('class','rojo');
			//IE
			elemento.setAttribute('className','rojo');
		} 
	} else {
		//alert("valor=" +valor);
		if (valor== "-" ){
			//firefox
			elemento.setAttribute('class','normal');
			//IE
			elemento.setAttribute('className','normal');
		} else {
			msg_error += '�Debes de introducir un n�mero!';
		} 
	}
	//mostramos error de validaci�n
	if (msg_error!=''){
		alert(msg_error);
		document.getElementById(nombre).value="";
	}

}//fin function valida
